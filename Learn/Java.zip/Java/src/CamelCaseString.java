import java.util.Arrays;
import java.util.HashSet;

public class CamelCaseString {
//    static String splitByUnderline(String str) {
//        String[] words = str.split("[A-Z]");
//        StringBuilder stringBuffer = new StringBuilder();
//        for (int i = 0; i < words.length; i++) {
//            stringBuffer.append(i >= 1 ? ("_" + words[i]) : words[i]);
//        }
//        return stringBuffer.toString();
//    }
//
//    static String toCamelCase(String str){
//        StringBuilder stringBuilder = new StringBuilder();
//        HashSet<Integer> set = new HashSet<>();
//        String[] words = str.split("_");
//        for (int i = 0; i < words.length; i++) {
//            set.add(words[i].length());
//            stringBuilder.append(words[i]);
//        }
//    }

    public static void main(String[] args) {
//        System.out.println(splitByUnderline("appleTree"));
//        System.out.println(toCamelCase("apple_tree"));
    }
}
