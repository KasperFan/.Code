package com.boda.practice;

public class VideoPlayer extends Player {
    public int duration;
    public void encodeVideo(){

    }

    @Override
    public void play() {

    }

    @Override
    public void stop() {

    }
}
