package com.boda.practice;

public abstract class Player {
    private String name;
    public abstract void play();
    public abstract void stop();
}
