package com.boda.practice;

public class MusicPlayer extends Player {
    public int volume;
    public void encodeAudio(){

    }

    @Override
    public void play() {

    }

    @Override
    public void stop() {

    }
}
