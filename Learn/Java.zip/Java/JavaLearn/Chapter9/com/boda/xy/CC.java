package com.boda.xy;

public interface CC extends AA,BB {
    int NUM = 3;                       // 定义一个常量
}
