package com.boda.xy;

public interface Eatable {
    // 抽象方法的定义
    String howToEat();
}
