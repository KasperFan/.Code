package com.boda.xy;

public interface AA {
    int STATUS = 100;       // 常量声明

    void display();         // 一个抽象方法
}
